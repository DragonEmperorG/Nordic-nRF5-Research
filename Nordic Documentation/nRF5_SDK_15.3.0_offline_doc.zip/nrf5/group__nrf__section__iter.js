var group__nrf__section__iter =
[
    [ "Section iterator configuration", "group__nrf__section__iter__config.html", "group__nrf__section__iter__config" ],
    [ "nrf_section_t", "structnrf__section__t.html", [
      [ "p_end", "structnrf__section__t.html#a6d9ccb6d3f24c392cc61592ecffb2df2", null ],
      [ "p_start", "structnrf__section__t.html#a5b4659a9f80b345b9c84796e2fea46f2", null ]
    ] ],
    [ "nrf_section_set_t", "structnrf__section__set__t.html", [
      [ "item_size", "structnrf__section__set__t.html#aa4bc260b9e17e06c6232d3e5dbbeacc9", null ],
      [ "p_first", "structnrf__section__set__t.html#a59bf4a989d32c5a7f9a686f4f8f45abc", null ],
      [ "p_last", "structnrf__section__set__t.html#af9965b1cb6123df8e9c53ce2da7bec44", null ]
    ] ],
    [ "nrf_section_iter_t", "structnrf__section__iter__t.html", [
      [ "p_item", "structnrf__section__iter__t.html#a2d0fd2bc34a12ae3207b3af58c83c162", null ],
      [ "p_section", "structnrf__section__iter__t.html#a1b42d45fe71e1218d2869c08b2e765aa", null ],
      [ "p_set", "structnrf__section__iter__t.html#afe380053eeb3f4e74f8bc79b8f4b9ebc", null ]
    ] ],
    [ "NRF_SECTION_SET_DEF", "group__nrf__section__iter.html#gac05b92d17078dfcb85ef7fd7b4de9783", null ],
    [ "NRF_SECTION_SET_ITEM_REGISTER", "group__nrf__section__iter.html#ga0d6f56fe6f518d0f5196a591155e4048", null ],
    [ "nrf_section_iter_get", "group__nrf__section__iter.html#gaeb1b580e5c0c0a5509d167cbd233dbb0", null ],
    [ "nrf_section_iter_init", "group__nrf__section__iter.html#gaeb7cb3b49a94c9ddcd5fa58e9a7cf458", null ],
    [ "nrf_section_iter_next", "group__nrf__section__iter.html#ga69f32c422014c05c1507b12e0a424e1d", null ]
];