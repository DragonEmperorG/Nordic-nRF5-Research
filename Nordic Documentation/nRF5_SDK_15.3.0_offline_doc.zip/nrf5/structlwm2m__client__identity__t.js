var structlwm2m__client__identity__t =
[
    [ "type", "structlwm2m__client__identity__t.html#ac54d197d81524c2c22b4e95d85178d23", null ],
    [ "value", "structlwm2m__client__identity__t.html#a070c1bb4ed64546a5a5a241c80df4a22", null ]
];