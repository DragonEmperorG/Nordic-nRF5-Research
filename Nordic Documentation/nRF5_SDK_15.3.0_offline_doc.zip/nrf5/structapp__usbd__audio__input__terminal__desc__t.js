var structapp__usbd__audio__input__terminal__desc__t =
[
    [ "bAssocTerminal", "structapp__usbd__audio__input__terminal__desc__t.html#aa15c6ffb1307780c9f59c3d986f59053", null ],
    [ "bDescriptorSubType", "structapp__usbd__audio__input__terminal__desc__t.html#a3dda3ad8a7e954ebe737bf278e00da71", null ],
    [ "bDescriptorType", "structapp__usbd__audio__input__terminal__desc__t.html#a5c305e5ad6d0d8575a41acd2b612d05a", null ],
    [ "bLength", "structapp__usbd__audio__input__terminal__desc__t.html#a6234e25ff05eaf3253a59e456413c7fa", null ],
    [ "bNrChannels", "structapp__usbd__audio__input__terminal__desc__t.html#a25b169754f15ef94e0a4a9a888d6f6ca", null ],
    [ "bTerminalID", "structapp__usbd__audio__input__terminal__desc__t.html#a2dd9efac0d278e2aa039ff5f23878122", null ],
    [ "iChannelNames", "structapp__usbd__audio__input__terminal__desc__t.html#ad1d4f51dabcb39e8e07865b504faa4ae", null ],
    [ "iTerminal", "structapp__usbd__audio__input__terminal__desc__t.html#a3b1244a1a9688ac500e69c69365fd1e8", null ],
    [ "wChannelConfig", "structapp__usbd__audio__input__terminal__desc__t.html#aade3b3004e386181c1676239d5e8d2df", null ],
    [ "wTerminalType", "structapp__usbd__audio__input__terminal__desc__t.html#adfdcb35e4b553f9eb9f9e79694bf0538", null ]
];