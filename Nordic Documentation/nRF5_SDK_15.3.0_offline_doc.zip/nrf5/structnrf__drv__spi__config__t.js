var structnrf__drv__spi__config__t =
[
    [ "bit_order", "structnrf__drv__spi__config__t.html#acabc54d74b8fdd19170fd636f4f9b810", null ],
    [ "frequency", "structnrf__drv__spi__config__t.html#a02cddf2d2b10812f23fe4c8a4ec26481", null ],
    [ "irq_priority", "structnrf__drv__spi__config__t.html#a1281bb80b96d4c69e56c3cff0df6be86", null ],
    [ "miso_pin", "structnrf__drv__spi__config__t.html#a10d5d3a81349c71eb5aa3b4a9258571a", null ],
    [ "mode", "structnrf__drv__spi__config__t.html#aa1fdb1a45476d716b37c0dd32b88a0ea", null ],
    [ "mosi_pin", "structnrf__drv__spi__config__t.html#a11168ad3b83086c3de03d775711d5560", null ],
    [ "orc", "structnrf__drv__spi__config__t.html#a9bcbefb1830d92c575c538f5efce8d05", null ],
    [ "sck_pin", "structnrf__drv__spi__config__t.html#abf3cf198b28cefa35a8cac4bebf490fc", null ],
    [ "ss_pin", "structnrf__drv__spi__config__t.html#a1f5f99c795ce50863cb244d771b756d0", null ]
];