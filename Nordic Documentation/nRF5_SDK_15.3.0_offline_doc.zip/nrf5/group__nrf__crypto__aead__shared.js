var group__nrf__crypto__aead__shared =
[
    [ "nrf_crypto_aead_info_t", "structnrf__crypto__aead__info__t.html", [
      [ "crypt_fn", "structnrf__crypto__aead__info__t.html#a53b74d1fd5aafa3f0cd4fbfaa34e0438", null ],
      [ "init_fn", "structnrf__crypto__aead__info__t.html#a1a4a29345f5656d8bb492422087f08e9", null ],
      [ "key_size", "structnrf__crypto__aead__info__t.html#a23649601322db962ebf7e7f62a6eee0a", null ],
      [ "mode", "structnrf__crypto__aead__info__t.html#abad5924c8c6fc52536f12a3de631ac1b", null ],
      [ "uninit_fn", "structnrf__crypto__aead__info__t.html#abbb6b1aa8861a7c8bd00431286d9c06e", null ]
    ] ],
    [ "nrf_crypto_aead_internal_context_t", "structnrf__crypto__aead__internal__context__t.html", [
      [ "init_value", "structnrf__crypto__aead__internal__context__t.html#adcfececafbbcd13e94f388aa665a7966", null ],
      [ "p_info", "structnrf__crypto__aead__internal__context__t.html#a9f216f17974377c614533c7933936a4b", null ]
    ] ]
];