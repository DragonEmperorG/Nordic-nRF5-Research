var structble__bas__c__evt__t =
[
    [ "bas_db", "structble__bas__c__evt__t.html#a487990200ac17cb01d0ec564114f4ee2", null ],
    [ "battery_level", "structble__bas__c__evt__t.html#aa06f57fc8285fed61a3c0dd89671f6d3", null ],
    [ "conn_handle", "structble__bas__c__evt__t.html#a2e50bd49902ecb19cd098a42f6eb8db4", null ],
    [ "evt_type", "structble__bas__c__evt__t.html#a19f2646a4734d1fc7cb27fdd7055fa55", null ],
    [ "params", "structble__bas__c__evt__t.html#a7c5f05affb304894356a03ce2ff7561f", null ]
];