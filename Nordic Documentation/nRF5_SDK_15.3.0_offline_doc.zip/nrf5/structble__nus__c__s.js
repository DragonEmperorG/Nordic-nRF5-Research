var structble__nus__c__s =
[
    [ "conn_handle", "structble__nus__c__s.html#a0710a16d0039005d0785a59bd026bc26", null ],
    [ "evt_handler", "structble__nus__c__s.html#ace9433f29798388fa6eadc3c871a0ce0", null ],
    [ "handles", "structble__nus__c__s.html#abb0e28d9b5b76579a656cb404ed39bab", null ],
    [ "uuid_type", "structble__nus__c__s.html#a5ce7a252048d5eb74bc6bdc707cddb94", null ]
];