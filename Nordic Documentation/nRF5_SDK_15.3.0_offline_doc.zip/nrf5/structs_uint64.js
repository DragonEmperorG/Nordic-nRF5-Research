var structs_uint64 =
[
    [ "dwHigherByte", "structs_uint64.html#abec0949c1c7e592c7a198340937d9708", null ],
    [ "dwLowerByte", "structs_uint64.html#ae8164a0321a3df077bfa997b5bf7acc7", null ]
];