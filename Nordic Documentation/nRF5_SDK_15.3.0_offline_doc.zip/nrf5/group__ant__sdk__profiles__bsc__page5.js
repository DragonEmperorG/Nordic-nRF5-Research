var group__ant__sdk__profiles__bsc__page5 =
[
    [ "ant_bsc_page5_data_t", "structant__bsc__page5__data__t.html", [
      [ "reserved", "structant__bsc__page5__data__t.html#a6e257d1080a333b538dc50d101622516", null ],
      [ "stop_indicator", "structant__bsc__page5__data__t.html#adbe2c63f0af30ee8b2c8012ff0096522", null ]
    ] ],
    [ "DEFAULT_ANT_BSC_PAGE5", "group__ant__sdk__profiles__bsc__page5.html#ga02bc64438ca7074a71e0f77ed2051935", null ],
    [ "ant_bsc_page_5_decode", "group__ant__sdk__profiles__bsc__page5.html#gaff758809066a7237e6a00af43427a461", null ],
    [ "ant_bsc_page_5_encode", "group__ant__sdk__profiles__bsc__page5.html#ga8c0037b5ccb264dee08d88019fde4d89", null ]
];