var structfds__record__desc__t =
[
    [ "gc_run_count", "structfds__record__desc__t.html#a3f9026d08333d6d844768715c8d3798a", null ],
    [ "p_record", "structfds__record__desc__t.html#a8d5f5c246887b31717118511e77fffda", null ],
    [ "record_id", "structfds__record__desc__t.html#aed10c12c07f6e41aa94760ddb0d6946f", null ],
    [ "record_is_open", "structfds__record__desc__t.html#aaf09412876893fa2029c9fb24f479ed4", null ]
];