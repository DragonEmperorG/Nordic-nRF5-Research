var structble__ans__control__point__t =
[
    [ "category", "structble__ans__control__point__t.html#a4fdff51ec3bc842205991b1d94a6203d", null ],
    [ "command", "structble__ans__control__point__t.html#a884740fe58c776baff9984a9aeb2364a", null ]
];