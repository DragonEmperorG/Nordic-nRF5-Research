var group__nfc__t4t__parser =
[
    [ "APDU reader/writer", "group__nfc__t4t__apdu.html", "group__nfc__t4t__apdu" ],
    [ "CC file parser", "group__nfc__t4t__cc__file.html", "group__nfc__t4t__cc__file" ],
    [ "High-level NDEF Detection Procedure", "group__nfc__t4t__hl__detection__procedures.html", "group__nfc__t4t__hl__detection__procedures" ]
];