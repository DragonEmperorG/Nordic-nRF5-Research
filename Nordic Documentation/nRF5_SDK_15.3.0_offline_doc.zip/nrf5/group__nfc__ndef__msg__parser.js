var group__nfc__ndef__msg__parser =
[
    [ "NFC NDEF message parser module configuration", "group__nfc__ndef__msg__parser__config.html", "group__nfc__ndef__msg__parser__config" ],
    [ "NDEF message parser (internal)", "group__nfc__ndef__msg__parser__local.html", "group__nfc__ndef__msg__parser__local" ],
    [ "NFC_NDEF_PARSER_REQIRED_MEMO_SIZE_CALC", "group__nfc__ndef__msg__parser.html#gaa8a00355585f90aac785605be72b0106", null ],
    [ "ndef_msg_parser", "group__nfc__ndef__msg__parser.html#gad0ef661cfcb1b7f52efa2705b6f99915", null ],
    [ "ndef_msg_printout", "group__nfc__ndef__msg__parser.html#ga6b15f0d6c830e30f06801920fbbb5619", null ]
];