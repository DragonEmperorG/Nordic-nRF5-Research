var group__crys__hmac__defs =
[
    [ "CRYS_HMAC_USER_CTX_SIZE_IN_WORDS", "group__crys__hmac__defs.html#ga4c3cf339aac343e71822779824ad2500", null ]
];