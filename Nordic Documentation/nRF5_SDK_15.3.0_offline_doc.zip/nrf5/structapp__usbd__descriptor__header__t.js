var structapp__usbd__descriptor__header__t =
[
    [ "bDescriptorType", "structapp__usbd__descriptor__header__t.html#abc24095d124969040bcc459ee54bc7c5", null ],
    [ "bLength", "structapp__usbd__descriptor__header__t.html#a037f416e6e363fc24a916d5fca3db83f", null ]
];