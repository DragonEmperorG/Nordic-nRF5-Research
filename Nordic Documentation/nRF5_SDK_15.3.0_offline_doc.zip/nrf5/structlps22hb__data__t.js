var structlps22hb__data__t =
[
    [ "pressure", "structlps22hb__data__t.html#a8913be2781f0e4c14442346d32252d02", null ],
    [ "temperature", "structlps22hb__data__t.html#a4741d563caae5b433d5c214e0fc2868a", null ]
];