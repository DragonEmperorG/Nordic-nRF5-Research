var group__nrf__systick =
[
    [ "ARM(R) SysTick driver - legacy layer", "group__nrf__drv__systick.html", "group__nrf__drv__systick" ],
    [ "ARM(R) SysTick driver", "group__nrfx__systick.html", "group__nrfx__systick" ],
    [ "SYSTICK HAL", "group__nrf__systick__hal.html", "group__nrf__systick__hal" ]
];