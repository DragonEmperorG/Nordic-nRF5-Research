var structnrfx__twis__config__t =
[
    [ "addr", "structnrfx__twis__config__t.html#ade797584795c337200eccfb8186ba4ab", null ],
    [ "interrupt_priority", "structnrfx__twis__config__t.html#aec05ce90a9a468da64026d810c04ef72", null ],
    [ "scl", "structnrfx__twis__config__t.html#ab03589e59b5fcca3bba1da3e78eb00d0", null ],
    [ "scl_pull", "structnrfx__twis__config__t.html#a1c58b94b3b4e6e803199f41dc52e0a6a", null ],
    [ "sda", "structnrfx__twis__config__t.html#aaee9a54d0800b0534cb0f4c4f665f807", null ],
    [ "sda_pull", "structnrfx__twis__config__t.html#a873cd180d2dd1106e260bcd2d61f1b8d", null ]
];