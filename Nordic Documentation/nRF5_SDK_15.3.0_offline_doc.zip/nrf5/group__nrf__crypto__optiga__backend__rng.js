var group__nrf__crypto__optiga__backend__rng =
[
    [ "Backends", "group__nrf__crypto__backends.html", "group__nrf__crypto__backends" ]
];