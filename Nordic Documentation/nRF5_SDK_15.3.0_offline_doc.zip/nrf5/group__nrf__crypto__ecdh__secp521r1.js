var group__nrf__crypto__ecdh__secp521r1 =
[
    [ "NRF_CRYPTO_ECDH_SECP521R1_SHARED_SECRET_SIZE", "group__nrf__crypto__ecdh__secp521r1.html#ga142354b1732fdc50514feb9c52495e74", null ],
    [ "nrf_crypto_ecdh_secp521r1_context_t", "group__nrf__crypto__ecdh__secp521r1.html#ga3d418ef20d53d4ad555b2b196e67b8f1", null ],
    [ "nrf_crypto_ecdh_secp521r1_shared_secret_t", "group__nrf__crypto__ecdh__secp521r1.html#gadadf42f2eaa25b404f53398677412dc1", null ]
];