var structble__rsc__t =
[
    [ "inst_cadence", "structble__rsc__t.html#a1794322c1691d6a5228dd103d12bb70f", null ],
    [ "inst_speed", "structble__rsc__t.html#a70029d424fbd66562028daef2699ffda", null ],
    [ "inst_stride_length", "structble__rsc__t.html#a0edb18e16462c8fa3705750f4469eb28", null ],
    [ "is_inst_stride_len_present", "structble__rsc__t.html#a2cc42c78e82f72f424f43d419404df2e", null ],
    [ "is_running", "structble__rsc__t.html#ac0ead28f01981a6cae5e161a9474a326", null ],
    [ "is_total_distance_present", "structble__rsc__t.html#a5076d2e2396070de8ce20cc68dadbd66", null ],
    [ "total_distance", "structble__rsc__t.html#a3cd4dc1f7f4cce8842345d96f2b31424", null ]
];