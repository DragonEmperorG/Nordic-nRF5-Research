var struct_c_r_y_s___d_h___fips_kat__t =
[
    [ "primeData", "struct_c_r_y_s___d_h___fips_kat__t.html#a1256f8afcc1e1d996e4eae363db49414", null ],
    [ "pubKey", "struct_c_r_y_s___d_h___fips_kat__t.html#ad3e0aefd12222240951d8e93658b2116", null ],
    [ "secretBuff", "struct_c_r_y_s___d_h___fips_kat__t.html#ae32f6f65e298939b047b421d13e7faa1", null ]
];