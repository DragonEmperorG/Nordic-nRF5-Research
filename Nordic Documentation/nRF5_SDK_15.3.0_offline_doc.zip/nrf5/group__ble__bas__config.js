var group__ble__bas__config =
[
    [ "BLE_BAS_CONFIG_DEBUG_COLOR", "group__ble__bas__config.html#gac58340ed9f17f6902257bc998291f7cc", null ],
    [ "BLE_BAS_CONFIG_INFO_COLOR", "group__ble__bas__config.html#ga94f4fac0886f94f8810513d29ee99db2", null ],
    [ "BLE_BAS_CONFIG_LOG_ENABLED", "group__ble__bas__config.html#gaabe12c593848b0a81c9cb8582e077e23", null ],
    [ "BLE_BAS_CONFIG_LOG_LEVEL", "group__ble__bas__config.html#ga582bb4d383379404c233c634781b3b19", null ],
    [ "BLE_BAS_ENABLED", "group__ble__bas__config.html#ga7aa4c68712ed0d38f3b734eaa4139c81", null ]
];