var group__nrfx__ppi__config =
[
    [ "NRFX_PPI_CONFIG_DEBUG_COLOR", "group__nrfx__ppi__config.html#ga4cdbcac8a747cbd8a4ab74c7cfdea6c6", null ],
    [ "NRFX_PPI_CONFIG_INFO_COLOR", "group__nrfx__ppi__config.html#ga7f34030aa785ace26b804311c04d9923", null ],
    [ "NRFX_PPI_CONFIG_LOG_ENABLED", "group__nrfx__ppi__config.html#ga781cd9989acc64deaa873d364856db1a", null ],
    [ "NRFX_PPI_CONFIG_LOG_LEVEL", "group__nrfx__ppi__config.html#gaa842c2e72a20e341518fbf6222c82a4d", null ],
    [ "NRFX_PPI_ENABLED", "group__nrfx__ppi__config.html#ga07594b831c405bcc621c203b4a27c29c", null ]
];