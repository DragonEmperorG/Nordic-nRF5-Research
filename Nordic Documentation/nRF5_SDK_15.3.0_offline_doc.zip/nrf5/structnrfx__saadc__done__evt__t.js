var structnrfx__saadc__done__evt__t =
[
    [ "p_buffer", "structnrfx__saadc__done__evt__t.html#a2361779a4d3268697a528e7160448fda", null ],
    [ "size", "structnrfx__saadc__done__evt__t.html#ae3681e189fc80ce07a42522df2df0c25", null ]
];