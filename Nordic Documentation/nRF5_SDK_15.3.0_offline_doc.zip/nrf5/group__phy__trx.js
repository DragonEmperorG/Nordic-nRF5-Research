var group__phy__trx =
[
    [ "plme_trx_req_t", "structplme__trx__req__t.html", [
      [ "state", "structplme__trx__req__t.html#a6aabc5a747e1351643cb7c2314bea6e6", null ]
    ] ],
    [ "plme_trx_conf_t", "structplme__trx__conf__t.html", [
      [ "status", "structplme__trx__conf__t.html#a02931a9034bbaee23b5b4d1dd2205981", null ]
    ] ],
    [ "plme_set_trx_state", "group__phy__trx.html#gaad58db8fbaec64903de671dd3f0ed8b9", null ],
    [ "plme_set_trx_state_conf", "group__phy__trx.html#ga2c970a9efc976b6cd917fec364c62647", null ],
    [ "plme_set_trx_state_req", "group__phy__trx.html#ga39ca067bd626f302fa02e0c218de5411", null ]
];