var unionapp__usbd__hid__descriptor__t =
[
    [ "bcdHID", "unionapp__usbd__hid__descriptor__t.html#a0aee7a62b19ceaff91bf66ef8829fe01", null ],
    [ "bCountryCode", "unionapp__usbd__hid__descriptor__t.html#a60a66300ee2c24bfebe9db90e5a54454", null ],
    [ "bDescriptorType", "unionapp__usbd__hid__descriptor__t.html#ab57775543a9a7cd991b99f05057805b3", null ],
    [ "bLength", "unionapp__usbd__hid__descriptor__t.html#a1baf86a578ce83f382dbe6844d672d05", null ],
    [ "bNumDescriptors", "unionapp__usbd__hid__descriptor__t.html#ae1c4c6d82c9e96677a21c0213c95f213", null ],
    [ "bRDescriptorType", "unionapp__usbd__hid__descriptor__t.html#af03493e55fa77f06945f6ab114108c4a", null ],
    [ "raw", "unionapp__usbd__hid__descriptor__t.html#a421fcc5d615eaa2992312734a74145c0", null ],
    [ "reports", "unionapp__usbd__hid__descriptor__t.html#a2add110b2751ad6810d8f4179d2f256c", null ],
    [ "wDescriptorLength", "unionapp__usbd__hid__descriptor__t.html#a8993c1b272f86def588f077720440dbd", null ]
];