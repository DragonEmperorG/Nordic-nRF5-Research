var group__ant__sdk__profiles__bpwr__page16 =
[
    [ "ant_bpwr_page16_data_t", "structant__bpwr__page16__data__t.html", [
      [ "accumulated_power", "structant__bpwr__page16__data__t.html#a3c3f98bb736ec31edb1fb5171f4a061f", null ],
      [ "byte", "structant__bpwr__page16__data__t.html#a75df93caeb145fb10eeb7a70a47e9d5a", null ],
      [ "differentiation", "structant__bpwr__page16__data__t.html#a0895abe8056540201f7dc8dbe81a685a", null ],
      [ "distribution", "structant__bpwr__page16__data__t.html#ada1d4af06da68500bcea84d81c5912ee", null ],
      [ "instantaneous_power", "structant__bpwr__page16__data__t.html#ac8854382edf3d2bfd22bfd69a64e275d", null ],
      [ "items", "structant__bpwr__page16__data__t.html#a8862b75e62d76e1d5d82dcd3207d7fd5", null ],
      [ "pedal_power", "structant__bpwr__page16__data__t.html#a79ca79fc4601b280a1ef4007e98a2763", null ],
      [ "update_event_count", "structant__bpwr__page16__data__t.html#a72d2a0b2a3332747bb525f7d3e276596", null ]
    ] ],
    [ "DEFAULT_ANT_BPWR_PAGE16", "group__ant__sdk__profiles__bpwr__page16.html#gaaf04103cccfe40e0d582522dbb4cda46", null ],
    [ "ant_bpwr_page_16_decode", "group__ant__sdk__profiles__bpwr__page16.html#ga880ca22ad59f6da1d8e69d6b8cf59a2d", null ],
    [ "ant_bpwr_page_16_encode", "group__ant__sdk__profiles__bpwr__page16.html#ga111b0c1f2d6e6b891709c0e2feb5f6f2", null ]
];