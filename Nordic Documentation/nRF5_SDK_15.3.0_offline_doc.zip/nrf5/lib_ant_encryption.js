var lib_ant_encryption =
[
    [ "Encryption configuration", "ant_enc_config.html", [
      [ "Cryptographic settings of the ANT stack", "ant_enc_config.html#ant_enc_config_stack", null ],
      [ "Channel initialization", "ant_enc_config.html#ant_enc_config_channel", null ],
      [ "Event handling", "ant_enc_config.html#ant_enc_config_events", null ]
    ] ],
    [ "Encryption negotiation", "ant_enc_negotiation.html", null ]
];