var group__cryptocell__pka =
[
    [ "CryptoCell PKA specific definitions", "group__crys__pka__defs__hw.html", "group__crys__pka__defs__hw" ],
    [ "CryptoCell PKA specific types and definitions", "group__ssi__pka__hw__plat__defs.html", "group__ssi__pka__hw__plat__defs" ]
];