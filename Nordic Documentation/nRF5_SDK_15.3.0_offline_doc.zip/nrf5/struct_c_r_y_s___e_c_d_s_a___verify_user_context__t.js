var struct_c_r_y_s___e_c_d_s_a___verify_user_context__t =
[
    [ "context_buff", "struct_c_r_y_s___e_c_d_s_a___verify_user_context__t.html#a75795bddd905a60facd2703f4283ec94", null ],
    [ "valid_tag", "struct_c_r_y_s___e_c_d_s_a___verify_user_context__t.html#a332914fdcccd7bb4f1d47c383e1c3805", null ]
];