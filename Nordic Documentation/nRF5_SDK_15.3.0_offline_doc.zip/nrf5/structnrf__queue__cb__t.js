var structnrf__queue__cb__t =
[
    [ "back", "structnrf__queue__cb__t.html#aefc56cab103a579ed4ecaf9be0420dc7", null ],
    [ "front", "structnrf__queue__cb__t.html#adbf07503c5385f8257b453b529e86c64", null ],
    [ "max_utilization", "structnrf__queue__cb__t.html#a6b69a6d0ae89dc05cd8d5d618462c51a", null ]
];