var structnrf__spi__mngr__transfer__t =
[
    [ "p_rx_data", "structnrf__spi__mngr__transfer__t.html#acd25eba5662c90fef6cd5757da22ab5d", null ],
    [ "p_tx_data", "structnrf__spi__mngr__transfer__t.html#aaef5d507844fc72369644b3cd7c8a467", null ],
    [ "rx_length", "structnrf__spi__mngr__transfer__t.html#ae835b316b81502cd51c0546f9189cdfb", null ],
    [ "tx_length", "structnrf__spi__mngr__transfer__t.html#adf8f42c1763fcbfbbb9527cc3dc454f2", null ]
];