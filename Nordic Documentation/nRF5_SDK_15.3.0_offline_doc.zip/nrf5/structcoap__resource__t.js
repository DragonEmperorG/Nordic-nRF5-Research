var structcoap__resource__t =
[
    [ "callback", "structcoap__resource__t.html#a1ff7de0fe8182ff2c04309f3f19c32dd", null ],
    [ "child_count", "structcoap__resource__t.html#aa726de3a396645384386e3220ca99608", null ],
    [ "ct_support_mask", "structcoap__resource__t.html#a8d5b288b837193d1458491be6a49f7da", null ],
    [ "expire_time", "structcoap__resource__t.html#a0cdccda28cee555b517f129f329e9197", null ],
    [ "max_age", "structcoap__resource__t.html#ada7ed80d8c8fabe131b5f5108f5fb50a", null ],
    [ "name", "structcoap__resource__t.html#ae0f7e5fdb6fdba055efc1688fda00c7e", null ],
    [ "p_front", "structcoap__resource__t.html#a89d5a9c7c8c1a8defb331f90e3cfe87d", null ],
    [ "p_sibling", "structcoap__resource__t.html#abe331eb3786e79a817b9f8141646fe45", null ],
    [ "p_tail", "structcoap__resource__t.html#ae3f9dc0b129b1b81a5f009ac1490d3f3", null ],
    [ "permission", "structcoap__resource__t.html#a27aaef2d7880e62bf430356355c871c5", null ]
];