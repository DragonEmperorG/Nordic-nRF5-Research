var group__ssi__pal__mutex =
[
    [ "SaSi_PalMutexCreate", "group__ssi__pal__mutex.html#gaea0dccbd14c52b5da220bd5c92101687", null ],
    [ "SaSi_PalMutexDestroy", "group__ssi__pal__mutex.html#ga6a620d502f18cbca65c2b193d40b3ac3", null ],
    [ "SaSi_PalMutexLock", "group__ssi__pal__mutex.html#ga26d8765ac146d6eba04a6e97d94ea778", null ],
    [ "SaSi_PalMutexUnlock", "group__ssi__pal__mutex.html#gaa82dc25bab4c97b75a8f93752adfb24b", null ]
];