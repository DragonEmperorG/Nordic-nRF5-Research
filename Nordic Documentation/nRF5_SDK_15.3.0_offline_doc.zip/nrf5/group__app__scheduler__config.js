var group__app__scheduler__config =
[
    [ "APP_SCHEDULER_ENABLED", "group__app__scheduler__config.html#gac6c156ce7b91554b94e5653ff6d8bbb1", null ],
    [ "APP_SCHEDULER_WITH_PAUSE", "group__app__scheduler__config.html#ga3779fbed374016753c852dfc17fae543", null ],
    [ "APP_SCHEDULER_WITH_PROFILER", "group__app__scheduler__config.html#gaf3d11fb8c3660d49872552215a0c5e01", null ]
];