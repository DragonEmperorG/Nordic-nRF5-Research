var structnrfx__nfct__evt__t =
[
    [ "error", "structnrfx__nfct__evt__t.html#addba562158932cb44f2bb32f1b6d15d3", null ],
    [ "evt_id", "structnrfx__nfct__evt__t.html#a52636ca0de072497f3d225d6f60ebb06", null ],
    [ "params", "structnrfx__nfct__evt__t.html#a7f7c28330341338f9a3c6d48e667eca2", null ],
    [ "rx_frameend", "structnrfx__nfct__evt__t.html#a28878b5bf8863b71020265348229ba34", null ],
    [ "tx_framestart", "structnrfx__nfct__evt__t.html#a9c02f7e0278108508fcded2e4231b180", null ]
];