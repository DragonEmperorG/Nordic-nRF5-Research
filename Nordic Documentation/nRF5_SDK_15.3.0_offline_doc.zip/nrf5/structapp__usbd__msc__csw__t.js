var structapp__usbd__msc__csw__t =
[
    [ "residue", "structapp__usbd__msc__csw__t.html#ad135a5ba8e780d674dd0495b6eae2af8", null ],
    [ "signature", "structapp__usbd__msc__csw__t.html#ac74b1f78431242cd4a7349cd092ae841", null ],
    [ "status", "structapp__usbd__msc__csw__t.html#ad00262582e4deb470a0ea82aad50c465", null ],
    [ "tag", "structapp__usbd__msc__csw__t.html#a87b07b9f2105c06bf4757ee8a5919402", null ]
];