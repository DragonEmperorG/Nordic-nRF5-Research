var struct_c_r_y_s___e_c_p_k_i___point_affine__t =
[
    [ "x", "struct_c_r_y_s___e_c_p_k_i___point_affine__t.html#afd13c95add3bb2b6d8f6e0eb3df3e85a", null ],
    [ "y", "struct_c_r_y_s___e_c_p_k_i___point_affine__t.html#a2668d44c4c344752a698c1e1ae02c1a8", null ]
];