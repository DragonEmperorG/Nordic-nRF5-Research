var group__soc__app =
[
    [ "ecb_block_encrypt_req_enc", "group__soc__app.html#gacadeeb2ea8d35fc871dc43605aed48e6", null ],
    [ "ecb_block_encrypt_rsp_dec", "group__soc__app.html#gaea48abad66a349b970ca06818ae2e3fd", null ],
    [ "power_system_off_req_enc", "group__soc__app.html#ga70416ff6e25fd59181a1ffaf24aeece8", null ],
    [ "temp_get_req_enc", "group__soc__app.html#ga7a321d0c704f19df22bf2a901c15c4c2", null ],
    [ "temp_get_rsp_dec", "group__soc__app.html#gac94d8d5d04917e46e1604a568ed790ec", null ]
];