var group__ser__conn =
[
    [ "Command decoder in the Connectivity Chip", "group__ser__cmd__decoder.html", "group__ser__cmd__decoder" ],
    [ "DTM Command Decoder in the Connectivity Chip", "group__ser__dtm__decoder.html", "group__ser__dtm__decoder" ],
    [ "Events encoder in the Connectivity Chip", "group__ser__event__encoder.html", "group__ser__event__encoder" ],
    [ "Events handlers in the Connectivity Chip", "group__ser__conn__handlers.html", "group__ser__conn__handlers" ],
    [ "Packets decoder in the Connectivity Chip", "group__ser__pkt__decoder.html", "group__ser__pkt__decoder" ]
];