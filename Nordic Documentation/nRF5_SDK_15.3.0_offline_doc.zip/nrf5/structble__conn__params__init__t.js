var structble__conn__params__init__t =
[
    [ "disconnect_on_fail", "structble__conn__params__init__t.html#abf5ac3620c0afeef3c3a04608094119a", null ],
    [ "error_handler", "structble__conn__params__init__t.html#a03b0ebe516b8abda6ae38a1d8bd94cf8", null ],
    [ "evt_handler", "structble__conn__params__init__t.html#aceb664463e99eb25dd703bca4e670038", null ],
    [ "first_conn_params_update_delay", "structble__conn__params__init__t.html#af2c34d78dad374ee7e2e443212b3912d", null ],
    [ "max_conn_params_update_count", "structble__conn__params__init__t.html#acc761ab28614393d35e59d0a11fdff76", null ],
    [ "next_conn_params_update_delay", "structble__conn__params__init__t.html#a406caf4a6f77cf13f9c4a4116bcdcad3", null ],
    [ "p_conn_params", "structble__conn__params__init__t.html#a4182d653bc49593db1dc32c47a3a2af0", null ],
    [ "start_on_notify_cccd_handle", "structble__conn__params__init__t.html#a6dcaa575801ddea65376594e964c3837", null ]
];