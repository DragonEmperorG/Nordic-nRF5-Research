var structnotification__t =
[
    [ "data", "structnotification__t.html#aefbb1c11e3a1d9addde1c6561e995912", null ],
    [ "handle", "structnotification__t.html#a7f5093396248404be137710d2dd7bd29", null ],
    [ "is_pending", "structnotification__t.html#a0d730d577b02f9f2915e6f0798a738a4", null ],
    [ "len", "structnotification__t.html#a401184b8986fa75c23431f210447bc77", null ]
];