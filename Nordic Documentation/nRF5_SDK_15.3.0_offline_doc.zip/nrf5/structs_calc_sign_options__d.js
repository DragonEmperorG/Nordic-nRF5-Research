var structs_calc_sign_options__d =
[
    [ "eSignScheme", "structs_calc_sign_options__d.html#a840bc8c7dccc740d4c4a13abd18fac99", null ],
    [ "sDigestToSign", "structs_calc_sign_options__d.html#ad371aa1977f2e30cb5e141f734c79362", null ],
    [ "wOIDSignKey", "structs_calc_sign_options__d.html#a2e277beb5e33bb103414d6afe6941d53", null ]
];