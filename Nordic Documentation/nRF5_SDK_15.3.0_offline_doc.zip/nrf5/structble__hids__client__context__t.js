var structble__hids__client__context__t =
[
    [ "ctrl_pt", "structble__hids__client__context__t.html#a0c037b300841797b30d307d7da48b204", null ],
    [ "protocol_mode", "structble__hids__client__context__t.html#adf1a8ba0e1cc628f1e34aa6e51cdbda4", null ]
];