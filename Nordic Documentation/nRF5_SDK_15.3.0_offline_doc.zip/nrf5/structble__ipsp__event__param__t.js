var structble__ipsp__event__param__t =
[
    [ "p_l2cap_evt", "structble__ipsp__event__param__t.html#a30d36568197a005951ec71b1b11c8831", null ],
    [ "p_peer", "structble__ipsp__event__param__t.html#a248a91f7ce44788b9b3ee91453947e7f", null ]
];