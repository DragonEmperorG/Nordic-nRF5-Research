var group__ser__codecs =
[
    [ "Application codecs", "group__ser__codecs__app.html", "group__ser__codecs__app" ],
    [ "Connectivity codecs", "group__ser__codecs__conn.html", "group__ser__codecs__conn" ],
    [ "Connectivity middleware codecs", "group__ser__codecs__mw.html", "group__ser__codecs__mw" ]
];