var structble__dis__c__s =
[
    [ "char_mask", "structble__dis__c__s.html#a9b28aa841864360cc9b9383fa98e1498", null ],
    [ "conn_handle", "structble__dis__c__s.html#a7eb9c2ac6d4b5d7a56e7d7d7813bcb87", null ],
    [ "error_handler", "structble__dis__c__s.html#a719e5df90ae205db0a161812bba0d2d6", null ],
    [ "evt_handler", "structble__dis__c__s.html#adbf8e6faea2e4054df62232b24f4a419", null ],
    [ "handles", "structble__dis__c__s.html#a17dd2c8191c8d277b109a1bbf3a5dbd6", null ]
];