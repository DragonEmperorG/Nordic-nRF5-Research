var structapp__usbd__scsi__cmd__write10__t =
[
    [ "control", "structapp__usbd__scsi__cmd__write10__t.html#aad1e54895a2c8ac1e07c8599607cdbd6", null ],
    [ "flags", "structapp__usbd__scsi__cmd__write10__t.html#a1146e184b6d24fa0590cec192a18779e", null ],
    [ "groupno", "structapp__usbd__scsi__cmd__write10__t.html#ac554104bebb778dc7118d733e343dc86", null ],
    [ "lba", "structapp__usbd__scsi__cmd__write10__t.html#a3304296fa6b1ce8347641980418236b6", null ],
    [ "opcode", "structapp__usbd__scsi__cmd__write10__t.html#a3657e556f00f02c89dbf081ed90b07c6", null ],
    [ "xfrlen", "structapp__usbd__scsi__cmd__write10__t.html#aaa028b13f0ededb30c01507c09ffdb0a", null ]
];