var structs_get_data__d =
[
    [ "eDataOrMdata", "structs_get_data__d.html#a4a93f0832ed2706ee63a0539ab19e436", null ],
    [ "wLength", "structs_get_data__d.html#a5dc6cd39de07d81ed0e4325b070bd47e", null ],
    [ "wOffset", "structs_get_data__d.html#adf8ca39a33033adf234292808739a455", null ],
    [ "wOID", "structs_get_data__d.html#a80e63826b8c4fbbf6f7d21dc4ec40e86", null ]
];