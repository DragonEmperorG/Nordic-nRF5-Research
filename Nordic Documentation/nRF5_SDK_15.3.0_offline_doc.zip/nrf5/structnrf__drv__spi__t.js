var structnrf__drv__spi__t =
[
    [ "inst_idx", "structnrf__drv__spi__t.html#a3549a53a04e7f297f76aecde28c6c01a", null ],
    [ "u", "structnrf__drv__spi__t.html#ae1b493c322e1ad70afb67d013888bd93", null ],
    [ "use_easy_dma", "structnrf__drv__spi__t.html#a508ade7ad9a712fac1efd021310b12a7", null ]
];