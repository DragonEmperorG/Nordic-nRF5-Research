var structnrf__sdh__stack__observer__t =
[
    [ "handler", "structnrf__sdh__stack__observer__t.html#a73b5a9ac9b2cafc3d69c47a399248b08", null ],
    [ "p_context", "structnrf__sdh__stack__observer__t.html#a66b3a0702ac2871803fbb99e0bb96c47", null ]
];