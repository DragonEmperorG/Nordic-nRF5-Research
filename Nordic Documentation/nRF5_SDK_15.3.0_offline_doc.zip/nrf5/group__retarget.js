var group__retarget =
[
    [ "Retargeting stdio functions configuration", "group__retarget__config.html", "group__retarget__config" ]
];