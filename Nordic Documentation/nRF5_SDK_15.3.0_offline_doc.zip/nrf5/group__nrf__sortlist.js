var group__nrf__sortlist =
[
    [ "Sorted list configuration", "group__nrf__sortlist__config.html", "group__nrf__sortlist__config" ],
    [ "nrf_sortlist_item_s", "structnrf__sortlist__item__s.html", [
      [ "p_next", "structnrf__sortlist__item__s.html#a0f2b8227cdf38e456e8102e14b01dcfe", null ]
    ] ],
    [ "nrf_sortlist_cb_t", "structnrf__sortlist__cb__t.html", [
      [ "p_head", "structnrf__sortlist__cb__t.html#a01bad2eb16d2d8851d2f2a3836e00de0", null ]
    ] ],
    [ "nrf_sortlist_t", "structnrf__sortlist__t.html", [
      [ "compare_func", "structnrf__sortlist__t.html#ab45a4a32591700d752550dea7458ad33", null ],
      [ "p_cb", "structnrf__sortlist__t.html#aa0dd4311084e690d5cf5611be48a2036", null ],
      [ "p_name", "structnrf__sortlist__t.html#a749dca76faf27d769293ed79a4a3eaa0", null ]
    ] ],
    [ "NRF_SORTLIST_DEF", "group__nrf__sortlist.html#gaed3767ba741df59ff3906b442eb8f1da", null ],
    [ "NRF_SORTLIST_INST_NAME", "group__nrf__sortlist.html#gacf239d1d762b10373ea162e7ffa7c248", null ],
    [ "nrf_sortlist_compare_func_t", "group__nrf__sortlist.html#gac0fecf6f3b70e3f7ccc5650063718ce9", null ],
    [ "nrf_sortlist_item_t", "group__nrf__sortlist.html#ga85d9561dd24468ef873e5a1e299b5434", null ],
    [ "nrf_sortlist_add", "group__nrf__sortlist.html#ga41cc9725174fcf6030f36445a9876786", null ],
    [ "nrf_sortlist_next", "group__nrf__sortlist.html#ga0be96aebc13780ce8a51e16948e7c07f", null ],
    [ "nrf_sortlist_peek", "group__nrf__sortlist.html#gaa360c68d9b416460a153e762148440a0", null ],
    [ "nrf_sortlist_pop", "group__nrf__sortlist.html#ga6f8da56ff572636c5569de5fade1e093", null ],
    [ "nrf_sortlist_remove", "group__nrf__sortlist.html#gaf9bf82dbf22cec36a88efb3c408cd7e3", null ]
];