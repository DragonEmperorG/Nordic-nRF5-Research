var structipso__illuminance__t =
[
    [ "max_measured_value", "structipso__illuminance__t.html#af4dc66549a6ec0daba4848f2ba7e4765", null ],
    [ "max_range_value", "structipso__illuminance__t.html#ab3b27b039e497bd57944271c9589ea5e", null ],
    [ "min_measured_value", "structipso__illuminance__t.html#abce30b13de5ddb62cd8ac885ac291c4c", null ],
    [ "min_range_value", "structipso__illuminance__t.html#aa021ca7ec66abc13a6ddbfaefa213c20", null ],
    [ "operations", "structipso__illuminance__t.html#a21f0d479f18388853612484d0b6bcba5", null ],
    [ "proto", "structipso__illuminance__t.html#a921e9e5cfeba627422b8c76dcf5e363c", null ],
    [ "resource_ids", "structipso__illuminance__t.html#ae87969974085f396c4bae1d96f8bad69", null ],
    [ "sensor_value", "structipso__illuminance__t.html#a37018dcbd8deb741e4259c7377aeea2d", null ],
    [ "units", "structipso__illuminance__t.html#aec5c8fd25824a91493dd2c66155bb81d", null ]
];