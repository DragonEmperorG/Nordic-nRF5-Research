var structnrf__ble__qwr__t =
[
    [ "attr_handles", "structnrf__ble__qwr__t.html#a8b46f082832fecf68b6335da8727b86c", null ],
    [ "callback", "structnrf__ble__qwr__t.html#ace12dd37dd0727c3189f3ae62df92e23", null ],
    [ "conn_handle", "structnrf__ble__qwr__t.html#af95c3980cb9b2f7b6250f58dffb1414f", null ],
    [ "error_handler", "structnrf__ble__qwr__t.html#aea20cce8417e23e5d5179a54424beb68", null ],
    [ "initialized", "structnrf__ble__qwr__t.html#a74ad5802bde9484fec23a62c70b715ca", null ],
    [ "is_user_mem_reply_pending", "structnrf__ble__qwr__t.html#a44846406b5ff8d594beeae95725a3db1", null ],
    [ "mem_buffer", "structnrf__ble__qwr__t.html#af7a91fa2f024ebe660b565775573f231", null ],
    [ "nb_registered_attr", "structnrf__ble__qwr__t.html#a8fe2dcb8930b2ba64816d85f2e4fd2d5", null ],
    [ "nb_written_handles", "structnrf__ble__qwr__t.html#ac277acc7a62378f5af1a142a6e41c15f", null ],
    [ "written_attr_handles", "structnrf__ble__qwr__t.html#a5f011d12f86643c954008c2e38daa337", null ]
];