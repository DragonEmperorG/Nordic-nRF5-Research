var structes__slot__t =
[
    [ "adv_custom_tx_power", "structes__slot__t.html#ab4a8d6a21658848fb61e7142d3d45e26", null ],
    [ "adv_frame", "structes__slot__t.html#a632d74a4e4fce5ddf50ca26b837fbb12", null ],
    [ "configured", "structes__slot__t.html#a0892127f5d1983c4f62413cb63d6a276", null ],
    [ "custom_tx_power", "structes__slot__t.html#a272ef5e340e47a49c34862041698b863", null ],
    [ "encrypted_eid_id_key", "structes__slot__t.html#aeb8bad0ebae191557d48414b1a321d50", null ],
    [ "ik", "structes__slot__t.html#a71226bc1175a496a9705197c760619e1", null ],
    [ "k_scaler", "structes__slot__t.html#ac16bbd6d8ac5360e279d2cee64035987", null ],
    [ "radio_tx_pwr", "structes__slot__t.html#aaa37ad176ac5e6bf391a6537bc262965", null ],
    [ "seconds", "structes__slot__t.html#acc1cdf4147e9b9115f62376ead222bbf", null ],
    [ "slot_no", "structes__slot__t.html#a1d65ab26d4626f0bd282dea00f0bbc0f", null ]
];