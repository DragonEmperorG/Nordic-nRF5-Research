var structnrf__drv__twi__config__t =
[
    [ "clear_bus_init", "structnrf__drv__twi__config__t.html#a777abe02eb4f7a5f94c165a8276ab9b2", null ],
    [ "frequency", "structnrf__drv__twi__config__t.html#a41e4e551c6db29e1dfec60a9dc57cc9a", null ],
    [ "hold_bus_uninit", "structnrf__drv__twi__config__t.html#a3b5245e38e8502cfbf05ee8c88d0f08c", null ],
    [ "interrupt_priority", "structnrf__drv__twi__config__t.html#a1787fc9d0846f00fb4e62cd843e4a589", null ],
    [ "scl", "structnrf__drv__twi__config__t.html#add3d7a404b8d303f3d0acdf17950adb5", null ],
    [ "sda", "structnrf__drv__twi__config__t.html#a8bf729ba64bea480b0beb5193b23af67", null ]
];