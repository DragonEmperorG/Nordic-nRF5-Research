var structant__hrm__page4__data__t =
[
    [ "manuf_spec", "structant__hrm__page4__data__t.html#a1abaf82491de12f2ce06726337a75e8f", null ],
    [ "prev_beat", "structant__hrm__page4__data__t.html#a5f6ad271f6e30011470f7da94ba801cc", null ]
];