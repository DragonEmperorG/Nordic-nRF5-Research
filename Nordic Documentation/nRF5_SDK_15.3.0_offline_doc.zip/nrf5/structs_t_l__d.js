var structs_t_l__d =
[
    [ "eCallType", "structs_t_l__d.html#a93a7f2e7e173d5053b939ba13121d1e2", null ],
    [ "eIsConnected", "structs_t_l__d.html#a94eef1d0c100ad029a43a656a2e520b3", null ],
    [ "phTLHdl", "structs_t_l__d.html#a38c9bff1893b2a5d029a3430fad4f78c", null ],
    [ "pzIpAddress", "structs_t_l__d.html#ab294cda004ef273052c09d12da33f677", null ],
    [ "sLogger", "structs_t_l__d.html#ac86cbfd21291bc73f19bfe873958f568", null ],
    [ "wPort", "structs_t_l__d.html#a54f40747955f95ababa73a3bc53a21c6", null ],
    [ "wTimeout", "structs_t_l__d.html#a00f98c79e355fa967d390726271413f0", null ]
];