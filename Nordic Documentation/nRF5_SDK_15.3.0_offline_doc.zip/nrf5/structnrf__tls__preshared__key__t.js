var structnrf__tls__preshared__key__t =
[
    [ "identity_len", "structnrf__tls__preshared__key__t.html#a1091a8eef107b7a96d8ef969bb60d684", null ],
    [ "p_identity", "structnrf__tls__preshared__key__t.html#ac3cc9d619d062be40d28ebca78dbcc79", null ],
    [ "p_secret_key", "structnrf__tls__preshared__key__t.html#a856e83b5dfa6ec19253bdb8f2e576c1f", null ],
    [ "secret_key_len", "structnrf__tls__preshared__key__t.html#a29b8a54d87ed05ac04f9add229c150c3", null ]
];