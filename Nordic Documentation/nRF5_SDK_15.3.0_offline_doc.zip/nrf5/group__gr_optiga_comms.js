var group__gr_optiga_comms =
[
    [ "optiga_comms", "structoptiga__comms.html", [
      [ "comms_ctx", "structoptiga__comms.html#a6f9c0a461b508069a2b3d87ecead8e94", null ],
      [ "state", "structoptiga__comms.html#a19ff6dc96cccde6ae2744e4284259c52", null ],
      [ "upper_layer_ctx", "structoptiga__comms.html#a203060e3e37e4d4d18d62a09b577b2b5", null ],
      [ "upper_layer_handler", "structoptiga__comms.html#a538bd20f765a1e1db82edb1489af06d6", null ]
    ] ],
    [ "OPTIGA_COMMS_BUSY", "group__gr_optiga_comms.html#ga455783785434227fd4a13da0b0d3d19b", null ],
    [ "OPTIGA_COMMS_ERROR", "group__gr_optiga_comms.html#ga1bb10db3c7a080407d6307abf9f94200", null ],
    [ "OPTIGA_COMMS_SUCCESS", "group__gr_optiga_comms.html#gaeff3f8160afeda4826b1ec5ca69edcd9", null ],
    [ "optiga_comms_t", "group__gr_optiga_comms.html#ga5515546b571b9e4c1f9f6e06028d82bb", null ],
    [ "optiga_comms_close", "group__gr_optiga_comms.html#gacce9ef0e7b80c6502218f866234e8cc3", null ],
    [ "optiga_comms_open", "group__gr_optiga_comms.html#ga183b71d32dae8fc70ee1bfb2a8ae8f56", null ],
    [ "optiga_comms_reset", "group__gr_optiga_comms.html#gacefcb5427adcb648da4141ec1d582d7c", null ],
    [ "optiga_comms_transceive", "group__gr_optiga_comms.html#ga34dbe4f51b1278ca6385d53751dd0a13", null ]
];