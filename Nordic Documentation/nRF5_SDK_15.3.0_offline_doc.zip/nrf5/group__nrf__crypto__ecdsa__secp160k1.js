var group__nrf__crypto__ecdsa__secp160k1 =
[
    [ "NRF_CRYPTO_ECDSA_SECP160K1_SIGNATURE_SIZE", "group__nrf__crypto__ecdsa__secp160k1.html#ga08a969dffe4e656ee36b85f4e149bc63", null ],
    [ "nrf_crypto_ecdsa_secp160k1_sign_context_t", "group__nrf__crypto__ecdsa__secp160k1.html#ga9b7bd6541f313ba454fbb51135e42bde", null ],
    [ "nrf_crypto_ecdsa_secp160k1_signature_t", "group__nrf__crypto__ecdsa__secp160k1.html#ga8abc6592435ead06928f41e761da05b0", null ],
    [ "nrf_crypto_ecdsa_secp160k1_verify_context_t", "group__nrf__crypto__ecdsa__secp160k1.html#gad743fc16ad5403ce135109518379ecc0", null ]
];