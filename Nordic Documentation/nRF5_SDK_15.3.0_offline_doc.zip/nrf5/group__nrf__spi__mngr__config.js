var group__nrf__spi__mngr__config =
[
    [ "NRF_SPI_MNGR_ENABLED", "group__nrf__spi__mngr__config.html#ga166c9d645015cbd8a80c6641c16f846f", null ]
];