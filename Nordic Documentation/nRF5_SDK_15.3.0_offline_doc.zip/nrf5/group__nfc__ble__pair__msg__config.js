var group__nfc__ble__pair__msg__config =
[
    [ "NFC_BLE_PAIR_MSG_ENABLED", "group__nfc__ble__pair__msg__config.html#ga56420011adaefbf25b4cde707bd703d5", null ]
];