var structant__encrypt__adv__burst__settings__t =
[
    [ "optional_feature", "structant__encrypt__adv__burst__settings__t.html#a8485a7c036734338b2aceaac7561fb6c", null ],
    [ "packet_length", "structant__encrypt__adv__burst__settings__t.html#af6ea567ab1dc1c3871856be676c229b4", null ],
    [ "required_feature", "structant__encrypt__adv__burst__settings__t.html#a86260cdfd170a3e48f262cf7b0664cd0", null ]
];