var structant__bsc__simulator__t =
[
    [ "_cb", "structant__bsc__simulator__t.html#a04e72f6d0fc4be33830dbdde54c14a81", null ],
    [ "p_profile", "structant__bsc__simulator__t.html#aa9eee71d8fd1fbb783d42212706341d4", null ]
];