var structnrfx__systick__state__t =
[
    [ "time", "structnrfx__systick__state__t.html#aeb6615c8bcee73d54e8768d33b74c1e9", null ]
];