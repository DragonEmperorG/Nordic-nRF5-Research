var structble__cscs__init__t =
[
    [ "csc_feature_rd_sec", "structble__cscs__init__t.html#aab1b78b0ce1691cc13eebad9b50934a1", null ],
    [ "csc_location_rd_sec", "structble__cscs__init__t.html#a08c90e3a89d348437cd192d160333c60", null ],
    [ "csc_meas_cccd_wr_sec", "structble__cscs__init__t.html#a86e815b29390b9fca57bd1a8202cbd0e", null ],
    [ "ctrlpt_evt_handler", "structble__cscs__init__t.html#ae231dc1f9d43bda606fa4b727caf3884", null ],
    [ "ctrplt_supported_functions", "structble__cscs__init__t.html#a15059621d6cb93de8b90767f76adc6e7", null ],
    [ "error_handler", "structble__cscs__init__t.html#a4396c5044bb0f5e1220c29a87b6ca54d", null ],
    [ "evt_handler", "structble__cscs__init__t.html#a9f766010d9a6bc81bb6797c1b4d5daf6", null ],
    [ "feature", "structble__cscs__init__t.html#ab63bfc8e6831331b8094ddff39f9f450", null ],
    [ "list_supported_locations", "structble__cscs__init__t.html#a373d7b18dfbd5752d3289df0ac9c2c0b", null ],
    [ "sc_ctrlpt_cccd_wr_sec", "structble__cscs__init__t.html#a9a5732ded3ff9c11e1c203f63e269a62", null ],
    [ "sc_ctrlpt_wr_sec", "structble__cscs__init__t.html#ac1a44d62a8303e81c41ed87c1b73838e", null ],
    [ "sensor_location", "structble__cscs__init__t.html#a3d866076247845450b80114da2d67b48", null ],
    [ "size_list_supported_locations", "structble__cscs__init__t.html#ac680f9557c992b9e2443b2fec6c022d1", null ]
];