var group__ble__advertising__config =
[
    [ "BLE_ADVERTISING_ENABLED", "group__ble__advertising__config.html#ga15b905d6c640fa2e34710d27a81d7f2a", null ]
];