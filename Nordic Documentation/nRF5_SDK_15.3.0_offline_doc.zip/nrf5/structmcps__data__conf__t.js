var structmcps__data__conf__t =
[
    [ "msdu_handle", "structmcps__data__conf__t.html#a7af2a1c74cf6b61aaffc63f2a1848472", null ],
    [ "status", "structmcps__data__conf__t.html#a646a165b8e0ac648bc68c0e1ed2334cf", null ],
    [ "timestamp", "structmcps__data__conf__t.html#aae464884058c8a73709dbf3e918fb907", null ]
];