var structble__db__discovery__t =
[
    [ "conn_handle", "structble__db__discovery__t.html#aea6b3ca0b15ba3d4684ac2dfaafb584b", null ],
    [ "curr_char_ind", "structble__db__discovery__t.html#a2ca30b7a259a7342dc23272fcd6d889f", null ],
    [ "curr_srv_ind", "structble__db__discovery__t.html#aa598c16586a07aa4b13e38c35b8b803d", null ],
    [ "discoveries_count", "structble__db__discovery__t.html#ae1cb837d11603bcb109b7043be91f849", null ],
    [ "discovery_in_progress", "structble__db__discovery__t.html#afca8a6f17e6b6d6c40f9fa490ed42b94", null ],
    [ "discovery_pending", "structble__db__discovery__t.html#af766085e2560f480066576c6ecbb6626", null ],
    [ "services", "structble__db__discovery__t.html#ac643dc3300ac0d664173dee922f38c8e", null ],
    [ "srv_count", "structble__db__discovery__t.html#a0cbdc7069a26178c67b3b558633fa261", null ]
];