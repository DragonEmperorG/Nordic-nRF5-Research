var group__nrf__drivers__sdio =
[
    [ "sdio_init", "group__nrf__drivers__sdio.html#gafd362e60216c5346709cac28c7cc175b", null ],
    [ "sdio_read_burst", "group__nrf__drivers__sdio.html#ga95ee69dbe058216ef73012a1ff04c077", null ],
    [ "sdio_read_byte", "group__nrf__drivers__sdio.html#ga1ff0f4956042d92b01fc2dbeffe26284", null ],
    [ "sdio_write_byte", "group__nrf__drivers__sdio.html#ga2e5d560f80ba374b7fe18f4e8a565ffd", null ]
];