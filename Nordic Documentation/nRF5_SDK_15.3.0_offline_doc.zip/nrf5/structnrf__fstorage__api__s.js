var structnrf__fstorage__api__s =
[
    [ "erase", "structnrf__fstorage__api__s.html#abe4e8871eda75c52d667b208b9e70c43", null ],
    [ "init", "structnrf__fstorage__api__s.html#a19d7c3605bf2b6e2e1c564769e14db08", null ],
    [ "is_busy", "structnrf__fstorage__api__s.html#ab49adb5aec6e0b2b673d9992e9e88f2c", null ],
    [ "read", "structnrf__fstorage__api__s.html#a3faf6ed3a5f86e0878114804c9c46083", null ],
    [ "rmap", "structnrf__fstorage__api__s.html#a17592e5a5a2b092e644db312fce7f271", null ],
    [ "uninit", "structnrf__fstorage__api__s.html#a0a98a930ba79673fd54380a6d5ded161", null ],
    [ "wmap", "structnrf__fstorage__api__s.html#a10017e0ee714fd25293313b696fe7702", null ],
    [ "write", "structnrf__fstorage__api__s.html#a11c5c2ddb080ce73d3b872fa17e4080e", null ]
];