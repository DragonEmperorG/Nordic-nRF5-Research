var group__ble__dis__config =
[
    [ "BLE_DIS_ENABLED", "group__ble__dis__config.html#ga2683880a407e6863cab98679b612613c", null ]
];