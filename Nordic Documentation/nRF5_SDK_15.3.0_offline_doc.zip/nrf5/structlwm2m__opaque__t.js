var structlwm2m__opaque__t =
[
    [ "len", "structlwm2m__opaque__t.html#a88a822a4f094ab5cd093d253fb7e4dfa", null ],
    [ "p_val", "structlwm2m__opaque__t.html#adb431da5cf9c0e92ed5f6c3f2bcc0b6f", null ]
];