var structant__request__controller__t =
[
    [ "page_70", "structant__request__controller__t.html#a016f4755c54ede8fe4bc54283134061a", null ],
    [ "state", "structant__request__controller__t.html#a81447ff586c286f651530410f4da4b27", null ]
];