var structplme__trx__req__t =
[
    [ "state", "structplme__trx__req__t.html#a6aabc5a747e1351643cb7c2314bea6e6", null ]
];