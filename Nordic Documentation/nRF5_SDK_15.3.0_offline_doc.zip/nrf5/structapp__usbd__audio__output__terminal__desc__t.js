var structapp__usbd__audio__output__terminal__desc__t =
[
    [ "bAssocTerminal", "structapp__usbd__audio__output__terminal__desc__t.html#af2307e634ad00a6f8fbdf9b2835d4362", null ],
    [ "bDescriptorSubType", "structapp__usbd__audio__output__terminal__desc__t.html#ab5d1427b89f4d3b03a6ad0887ec64946", null ],
    [ "bDescriptorType", "structapp__usbd__audio__output__terminal__desc__t.html#ad8497679d7dbe30513aba0a3291550e9", null ],
    [ "bLength", "structapp__usbd__audio__output__terminal__desc__t.html#a2d6d892e41282ba5fc54782b62811e15", null ],
    [ "bSourceID", "structapp__usbd__audio__output__terminal__desc__t.html#a06fb6cbd59c915c45b5f36039592df27", null ],
    [ "bTerminalID", "structapp__usbd__audio__output__terminal__desc__t.html#a09bcc5f8bfcff77b2ab07f32ade30ec1", null ],
    [ "iTerminal", "structapp__usbd__audio__output__terminal__desc__t.html#afa90a43d70095b4fa3107830426c2736", null ],
    [ "wTerminalType", "structapp__usbd__audio__output__terminal__desc__t.html#a6a9efa360d9240a3aaaee542848d99a2", null ]
];