var structnrfx__twim__evt__t =
[
    [ "type", "structnrfx__twim__evt__t.html#af6ab45b6e0e27663c93e08a9f6dfe1dc", null ],
    [ "xfer_desc", "structnrfx__twim__evt__t.html#a79ec46a97187f17ac10b8e8cfec91fd9", null ]
];