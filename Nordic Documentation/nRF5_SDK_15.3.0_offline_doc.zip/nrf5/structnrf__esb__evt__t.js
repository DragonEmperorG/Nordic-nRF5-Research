var structnrf__esb__evt__t =
[
    [ "evt_id", "structnrf__esb__evt__t.html#a2eb9d5c5a6a503ec81f271ecd91fd534", null ],
    [ "tx_attempts", "structnrf__esb__evt__t.html#a936a389f13fe92f4cf61e7f8e50a9e87", null ]
];