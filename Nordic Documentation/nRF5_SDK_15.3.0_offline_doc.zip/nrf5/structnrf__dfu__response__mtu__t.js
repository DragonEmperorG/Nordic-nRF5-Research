var structnrf__dfu__response__mtu__t =
[
    [ "size", "structnrf__dfu__response__mtu__t.html#a3b817812dfb0bc9f013c04a7e53f573a", null ]
];