var structapp__usbd__descriptor__ep__t =
[
    [ "bDescriptorType", "structapp__usbd__descriptor__ep__t.html#a5aed0b738b987cf290a6f10fa826eaf3", null ],
    [ "bEndpointAddress", "structapp__usbd__descriptor__ep__t.html#ae7c74838f19cc0a210ef111e4f9aebac", null ],
    [ "bInterval", "structapp__usbd__descriptor__ep__t.html#a99fb3990ae8034fdc4b4684866ac8589", null ],
    [ "bLength", "structapp__usbd__descriptor__ep__t.html#ac83abae1f48c05b295e4e21e9a3537d8", null ],
    [ "bmAttributes", "structapp__usbd__descriptor__ep__t.html#aae3187b9d2f220ace599253822302685", null ],
    [ "wMaxPacketSize", "structapp__usbd__descriptor__ep__t.html#a5f2c2e7ecbc133cf095c6eb23d6e263f", null ]
];