var group__nrf__dfu__settings =
[
    [ "DFU Settings configuration", "group__nrf__dfu__settings__config.html", "group__nrf__dfu__settings__config" ],
    [ "nrf_dfu_settings_additional_erase", "group__nrf__dfu__settings.html#gaf11a920f95abaea22cc6e59614555abe", null ],
    [ "nrf_dfu_settings_backup", "group__nrf__dfu__settings.html#ga779fe98efbb417dbf934855d016aedd0", null ],
    [ "nrf_dfu_settings_init", "group__nrf__dfu__settings.html#gaacc64ef4cda7940866d2479ce39b0cc8", null ],
    [ "nrf_dfu_settings_write", "group__nrf__dfu__settings.html#ga50aa87620c5d3356c3b244b752830cea", null ],
    [ "nrf_dfu_settings_write_and_backup", "group__nrf__dfu__settings.html#ga336942d2117e796635e48032605734c0", null ],
    [ "s_dfu_settings", "group__nrf__dfu__settings.html#gaea8ed0d20006b2509636a6ff6e8a349d", null ]
];