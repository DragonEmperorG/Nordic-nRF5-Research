var structipso__light__control__t =
[
    [ "colour", "structipso__light__control__t.html#af3463f5bebba65c790fb3839ec853578", null ],
    [ "cumulative_active_power", "structipso__light__control__t.html#addf8b5137de0882c5691f6b81c6ab7b8", null ],
    [ "dimmer", "structipso__light__control__t.html#a367ebb7d6bcdddee43a53792df981601", null ],
    [ "on", "structipso__light__control__t.html#adfba4c8abed429cb491d984d03855b7b", null ],
    [ "on_time", "structipso__light__control__t.html#a1e5a43ddb4d5534e143edddb3c902da6", null ],
    [ "operations", "structipso__light__control__t.html#acb6d2f687f4a7c525963671d144fc808", null ],
    [ "power_factor", "structipso__light__control__t.html#aee2e646f613500629471d618e5465aed", null ],
    [ "proto", "structipso__light__control__t.html#a9784efdc190fbae3b4b6bfe9728e8a14", null ],
    [ "resource_ids", "structipso__light__control__t.html#a0255d4d8a02a72101151685e63b87a48", null ],
    [ "units", "structipso__light__control__t.html#a990e763fbd7cf482b8d3e8fcd6df3a1d", null ]
];