var structiot__pbuffer__t =
[
    [ "length", "structiot__pbuffer__t.html#a9819ae5969c53e86e67c8ab023f29b8c", null ],
    [ "p_memory", "structiot__pbuffer__t.html#a83af9f09279251888d72d4e8a9685931", null ],
    [ "p_payload", "structiot__pbuffer__t.html#af72d5cf4c52c8dadaa7982f3250e2489", null ],
    [ "type", "structiot__pbuffer__t.html#a71e6128be5efbcf0ab43faf5d34f9052", null ]
];