var group__nrf__crypto__ecdsa__secp521r1 =
[
    [ "NRF_CRYPTO_ECDSA_SECP521R1_SIGNATURE_SIZE", "group__nrf__crypto__ecdsa__secp521r1.html#ga12faa30463f37fcdf84186a14c2d1e73", null ],
    [ "nrf_crypto_ecdsa_secp521r1_sign_context_t", "group__nrf__crypto__ecdsa__secp521r1.html#ga965be1ec0144ba18fedb5131057ebaf4", null ],
    [ "nrf_crypto_ecdsa_secp521r1_signature_t", "group__nrf__crypto__ecdsa__secp521r1.html#ga7b4ed736f83609fef9996e505ce4d684", null ],
    [ "nrf_crypto_ecdsa_secp521r1_verify_context_t", "group__nrf__crypto__ecdsa__secp521r1.html#ga46f58ad55dcca20626d160cc1a60baab", null ]
];