var structnrf__log__header__t =
[
    [ "base", "structnrf__log__header__t.html#ab2dbe82f79c6e569c6523290b5997736", null ],
    [ "dropped", "structnrf__log__header__t.html#a163e0afa6e11f2ca1e2b8e258a309ead", null ],
    [ "module_id", "structnrf__log__header__t.html#a296548352f0cdbe3d214e1c126a50425", null ],
    [ "timestamp", "structnrf__log__header__t.html#a5eac3732fc9e38153a483dca2b4dbd3f", null ]
];