var structnfc__ble__oob__pairing__data__t =
[
    [ "appearance", "structnfc__ble__oob__pairing__data__t.html#a9b46b09e6f6861c9a9b2b7d94d7bc859", null ],
    [ "device_name", "structnfc__ble__oob__pairing__data__t.html#a8504075b3fdee8ebdbfc8e366ec3fa40", null ],
    [ "flags", "structnfc__ble__oob__pairing__data__t.html#af01e8c476bbf492ddceab628511646f0", null ],
    [ "le_role", "structnfc__ble__oob__pairing__data__t.html#aee55406747fdb88e3e949e799031787e", null ],
    [ "p_device_addr", "structnfc__ble__oob__pairing__data__t.html#a5381aee7da2c9d763591258a85537b76", null ],
    [ "p_lesc_confirm_value", "structnfc__ble__oob__pairing__data__t.html#aa2c4cf2baace840de0a41da3ca27c761", null ],
    [ "p_lesc_random_value", "structnfc__ble__oob__pairing__data__t.html#a99b3f570028261f3dd99cfe38dbbd8a7", null ],
    [ "p_sec_mgr_oob_flags", "structnfc__ble__oob__pairing__data__t.html#ac2faf9d02c57f049ee20b10aa6b68721", null ],
    [ "p_tk_value", "structnfc__ble__oob__pairing__data__t.html#a799d59b513327879f8cdb4d1561c684c", null ]
];