var structble__lbs__c__evt__t =
[
    [ "button", "structble__lbs__c__evt__t.html#a66f37da9f74290f340749caec0f762a4", null ],
    [ "conn_handle", "structble__lbs__c__evt__t.html#ae126c87a80af21208140ae74c09c7e01", null ],
    [ "evt_type", "structble__lbs__c__evt__t.html#a9ee4d99724aaccd7039f3c2fc2395d75", null ],
    [ "params", "structble__lbs__c__evt__t.html#a3228ee3f1e38bd185b97e0e7e18e468a", null ],
    [ "peer_db", "structble__lbs__c__evt__t.html#ab1c539d2a207d01e8fba6521ec9d7ca0", null ]
];