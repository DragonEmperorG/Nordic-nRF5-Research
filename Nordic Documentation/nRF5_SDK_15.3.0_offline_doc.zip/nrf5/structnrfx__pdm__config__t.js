var structnrfx__pdm__config__t =
[
    [ "clock_freq", "structnrfx__pdm__config__t.html#a158de0520c19f2bdf83c1b3c4bc4c164", null ],
    [ "edge", "structnrfx__pdm__config__t.html#a4efeaec7d1969b87969024790302b59e", null ],
    [ "gain_l", "structnrfx__pdm__config__t.html#ad96795474694d76d72850a1f02c4d680", null ],
    [ "gain_r", "structnrfx__pdm__config__t.html#a8122189fb2235fc095e86c6a358e9fa8", null ],
    [ "interrupt_priority", "structnrfx__pdm__config__t.html#a4c04b615c9abccc5ba7950baa10b92ef", null ],
    [ "mode", "structnrfx__pdm__config__t.html#afc2ed6a7553925b607cb771c1ad55bee", null ],
    [ "pin_clk", "structnrfx__pdm__config__t.html#a81d8e44e499eddc087502d413146685f", null ],
    [ "pin_din", "structnrfx__pdm__config__t.html#abdeccf02fa5dbb362ab2c4cfcba1ddc0", null ]
];