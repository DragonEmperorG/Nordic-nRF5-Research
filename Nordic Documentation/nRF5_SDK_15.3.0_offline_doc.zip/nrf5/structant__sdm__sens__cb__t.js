var structant__sdm__sens__cb__t =
[
    [ "common_page_number", "structant__sdm__sens__cb__t.html#a76f26a5a1cc6cf189fc485b79d903d29", null ],
    [ "message_counter", "structant__sdm__sens__cb__t.html#ad5972a11c1799a32052bfd138fba0819", null ],
    [ "req_controller", "structant__sdm__sens__cb__t.html#a074797dd306f2616f659df85dde0a494", null ],
    [ "supp_page_control", "structant__sdm__sens__cb__t.html#a36132b4aa245edd7a28dc8a10057bb0b", null ],
    [ "supp_page_number", "structant__sdm__sens__cb__t.html#ae76d97150be15b95567aab6ff02831ff", null ]
];