var structparsed__ndef__msg__2__t =
[
    [ "bin_pay_desc", "structparsed__ndef__msg__2__t.html#a0c3f8cb2a9f20e54aed2dd09e662a59f", null ],
    [ "msg_desc", "structparsed__ndef__msg__2__t.html#a0ab99882f00300f154e58c70fae33ff9", null ],
    [ "p_record_desc_array", "structparsed__ndef__msg__2__t.html#a9296e57143ba82147a26666b995ffb50", null ],
    [ "rec_desc", "structparsed__ndef__msg__2__t.html#ab0f616c4dae079171fde011ed9e59ba5", null ]
];