var structnrf__cli__cdc__acm__internal__t =
[
    [ "p_cb", "structnrf__cli__cdc__acm__internal__t.html#a30492a99e3e964aa15383303c2cdb55b", null ],
    [ "transport", "structnrf__cli__cdc__acm__internal__t.html#a6cbde915e0c510f9ba33d641c5fd3475", null ]
];