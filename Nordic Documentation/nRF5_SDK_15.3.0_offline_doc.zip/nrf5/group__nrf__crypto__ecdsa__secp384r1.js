var group__nrf__crypto__ecdsa__secp384r1 =
[
    [ "NRF_CRYPTO_ECDSA_SECP384R1_SIGNATURE_SIZE", "group__nrf__crypto__ecdsa__secp384r1.html#ga3c94e34caa5c94bacfb4b6e66f7689d4", null ],
    [ "nrf_crypto_ecdsa_secp384r1_sign_context_t", "group__nrf__crypto__ecdsa__secp384r1.html#ga1602c69d05587560c1ebcda9b8bf1274", null ],
    [ "nrf_crypto_ecdsa_secp384r1_signature_t", "group__nrf__crypto__ecdsa__secp384r1.html#ga02f2f9f27778e7f0a88af967d72974d1", null ],
    [ "nrf_crypto_ecdsa_secp384r1_verify_context_t", "group__nrf__crypto__ecdsa__secp384r1.html#ga93971f82859a5aa26962367c9aa4619a", null ]
];