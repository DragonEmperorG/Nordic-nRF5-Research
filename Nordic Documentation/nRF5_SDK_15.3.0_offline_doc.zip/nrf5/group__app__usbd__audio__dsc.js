var group__app__usbd__audio__dsc =
[
    [ "APP_USBD_AUDIO_AC_IFACE_HEADER_DSC", "group__app__usbd__audio__dsc.html#gaccc5f2544dd58721c75c3114e870b274", null ],
    [ "APP_USBD_AUDIO_AS_FORMAT_I_DSC", "group__app__usbd__audio__dsc.html#ga84af32466f071503c2f809cb16bf58ad", null ],
    [ "APP_USBD_AUDIO_AS_FORMAT_II_DSC", "group__app__usbd__audio__dsc.html#ga42c3ffc00d3d30de4551659ef9d2a458", null ],
    [ "APP_USBD_AUDIO_AS_FORMAT_III_DSC", "group__app__usbd__audio__dsc.html#gad2fe58576e7688a63d28aaed9c9c1d69", null ],
    [ "APP_USBD_AUDIO_AS_IFACE_DSC", "group__app__usbd__audio__dsc.html#gaedc8dc67a496d0324831613a44a43d0a", null ],
    [ "APP_USBD_AUDIO_CONTROL_DSC", "group__app__usbd__audio__dsc.html#gaef921b00fa723285c1fa3ef13df4cfd5", null ],
    [ "APP_USBD_AUDIO_EP_GENERAL_DSC", "group__app__usbd__audio__dsc.html#gaebed84f76d3cc25c2f5ddaca1a5e44f7", null ],
    [ "APP_USBD_AUDIO_FEATURE_UNIT_DSC", "group__app__usbd__audio__dsc.html#ga56894650782f3c8f69cc63528cc1e196", null ],
    [ "APP_USBD_AUDIO_INPUT_TERMINAL_DSC", "group__app__usbd__audio__dsc.html#ga40f7b549eb2a9399a87ef464561c3885", null ],
    [ "APP_USBD_AUDIO_INTERFACE_DSC", "group__app__usbd__audio__dsc.html#gaa65c53d6de9f33551e89ad1b3cbf2a24", null ],
    [ "APP_USBD_AUDIO_ISO_EP_DSC", "group__app__usbd__audio__dsc.html#gaf7eafcd1f23adcc06e51bbdf428b7fe2", null ],
    [ "APP_USBD_AUDIO_ISO_EP_IN_DSC", "group__app__usbd__audio__dsc.html#ga1c4e3371cd81a0936df779ef9c218e29", null ],
    [ "APP_USBD_AUDIO_ISO_EP_OUT_DSC", "group__app__usbd__audio__dsc.html#gaf2277d619252fb93628d26ed1e1896e0", null ],
    [ "APP_USBD_AUDIO_MIDI_STREAMING_DSC", "group__app__usbd__audio__dsc.html#ga4cb23c3be1dad164194cb32af53f609f", null ],
    [ "APP_USBD_AUDIO_OUTPUT_TERMINAL_DSC", "group__app__usbd__audio__dsc.html#gadef33b05f8d70091b084b7609f1da6b5", null ],
    [ "APP_USBD_AUDIO_STREAMING_DSC", "group__app__usbd__audio__dsc.html#gabfdd5d08f7b89c37ca36e37ec14f5641", null ]
];