var group__ble__sdk__srv__ots__obj =
[
    [ "ble_ots_object_on_ble_evt", "group__ble__sdk__srv__ots__obj.html#gae414697508524c40d42a4b07a704f65c", null ],
    [ "ble_ots_object_refresh_current", "group__ble__sdk__srv__ots__obj.html#gaf75baf80b7f2c26b3deb199cee3ec102", null ],
    [ "ble_ots_object_representation_init", "group__ble__sdk__srv__ots__obj.html#ga91b6c2050e9826d9374d933985b727e9", null ]
];