var group__crys__poly__error =
[
    [ "CRYS_POLY_DATA_INVALID_ERROR", "group__crys__poly__error.html#gaf0cfe10a61bbaff42dab55141543fe1a", null ],
    [ "CRYS_POLY_DATA_SIZE_INVALID_ERROR", "group__crys__poly__error.html#gad60d52c0d1a308ced01ebda70816a5a1", null ],
    [ "CRYS_POLY_KEY_INVALID_ERROR", "group__crys__poly__error.html#ga8b123e12fa02f8c96052c7e4d66bf22b", null ],
    [ "CRYS_POLY_MAC_CALCULATION_ERROR", "group__crys__poly__error.html#gae323e544290c939da8263088b1d16909", null ]
];