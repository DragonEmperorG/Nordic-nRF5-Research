var structnrf__cli =
[
    [ "p_cmd_hist_mempool", "structnrf__cli.html#a5ddbe8bc0265bd7a666e87a3daf77089", null ],
    [ "p_ctx", "structnrf__cli.html#a5b4862cbdfe0ee0c8bc865900e903e36", null ],
    [ "p_fprintf_ctx", "structnrf__cli.html#a7ff24c8e806ec815dbe0821e23cf70cc", null ],
    [ "p_iface", "structnrf__cli.html#aa4feb29c746e28ed6559a78bc8b3e9fd", null ],
    [ "p_log_backend", "structnrf__cli.html#abf559133ba2754f14a92143e8ac9e080", null ],
    [ "p_name", "structnrf__cli.html#a04958fbfc705da52b9303bd7b5296440", null ]
];