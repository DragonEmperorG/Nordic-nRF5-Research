var group__nrf__cli__cdc__acm__config =
[
    [ "NRF_CLI_CDC_ACM_COMM_EPIN", "group__nrf__cli__cdc__acm__config.html#ga6efbc3edca3e72906a3a7bc188b78f7f", null ],
    [ "NRF_CLI_CDC_ACM_COMM_INTERFACE", "group__nrf__cli__cdc__acm__config.html#ga074a74f4cbff97ecbdbb907311e98ef6", null ],
    [ "NRF_CLI_CDC_ACM_DATA_EPIN", "group__nrf__cli__cdc__acm__config.html#ga5f9630f747c397282db353fe4d18ee2e", null ],
    [ "NRF_CLI_CDC_ACM_DATA_EPOUT", "group__nrf__cli__cdc__acm__config.html#ga3a3fa97a8590c28145c5977d7ab019bb", null ],
    [ "NRF_CLI_CDC_ACM_DATA_INTERFACE", "group__nrf__cli__cdc__acm__config.html#ga9c0726664d58007acfef863005e02659", null ],
    [ "NRF_CLI_CDC_ACM_ENABLED", "group__nrf__cli__cdc__acm__config.html#gab8f824f779ee8c68b35e29a3e200fdf2", null ]
];