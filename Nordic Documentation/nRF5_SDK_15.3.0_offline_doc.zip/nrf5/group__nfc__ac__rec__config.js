var group__nfc__ac__rec__config =
[
    [ "NFC_AC_REC_ENABLED", "group__nfc__ac__rec__config.html#ga0b00dc096a0a70399ff4060cdc2d4f73", null ]
];