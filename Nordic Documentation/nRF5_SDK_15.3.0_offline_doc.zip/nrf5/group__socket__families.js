var group__socket__families =
[
    [ "AF_INET", "group__socket__families.html#ga9930604d0e32588eae76f43ca38e7826", null ],
    [ "AF_INET6", "group__socket__families.html#gaa03706b2738b9a58d4985dfbe99e1bac", null ],
    [ "AF_NRF_CFG", "group__socket__families.html#ga74dfe8a984f94bbafbb020c244c19312", null ]
];