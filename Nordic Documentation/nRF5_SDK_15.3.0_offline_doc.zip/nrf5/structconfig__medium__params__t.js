var structconfig__medium__params__t =
[
    [ "error_handler", "structconfig__medium__params__t.html#a6d40f11308c13dee73b268273d79ca44", null ],
    [ "evt_handler", "structconfig__medium__params__t.html#a02fa1ae99bd8acd80da63f8443685d27", null ],
    [ "medium_type", "structconfig__medium__params__t.html#a5a0e30908376293f7379e463f7733af9", null ]
];