var structble__ias__c__init__t =
[
    [ "error_handler", "structble__ias__c__init__t.html#a83986799fa5972b6665f1dd70af89bca", null ],
    [ "evt_handler", "structble__ias__c__init__t.html#a53302faad4381a87101012bf06af6101", null ]
];