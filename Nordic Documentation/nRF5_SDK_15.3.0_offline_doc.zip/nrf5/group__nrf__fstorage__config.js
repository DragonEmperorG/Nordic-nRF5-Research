var group__nrf__fstorage__config =
[
    [ "NRF_FSTORAGE_ENABLED", "group__nrf__fstorage__config.html#gae494531b286304745aebe6369bc2f023", null ],
    [ "NRF_FSTORAGE_PARAM_CHECK_DISABLED", "group__nrf__fstorage__config.html#ga5e73baaef23c73565e9d942648592257", null ],
    [ "NRF_FSTORAGE_SD_MAX_RETRIES", "group__nrf__fstorage__config.html#ga9dae667c08aba31a7afd82ff627bdc09", null ],
    [ "NRF_FSTORAGE_SD_MAX_WRITE_SIZE", "group__nrf__fstorage__config.html#gad6e1d9ce4bc885ad5585f776e831b1dc", null ],
    [ "NRF_FSTORAGE_SD_QUEUE_SIZE", "group__nrf__fstorage__config.html#ga252e29d6763cd2562e44d0167f26f2a6", null ]
];