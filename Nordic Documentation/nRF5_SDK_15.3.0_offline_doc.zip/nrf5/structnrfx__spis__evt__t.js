var structnrfx__spis__evt__t =
[
    [ "evt_type", "structnrfx__spis__evt__t.html#a048cd624dcad090ae6f9319ff9d9df76", null ],
    [ "rx_amount", "structnrfx__spis__evt__t.html#a4997784101e4c75ba21d9a971e6a85c3", null ],
    [ "tx_amount", "structnrfx__spis__evt__t.html#a7c0cb2a6b035a4b4d36cf9286f8b23c8", null ]
];