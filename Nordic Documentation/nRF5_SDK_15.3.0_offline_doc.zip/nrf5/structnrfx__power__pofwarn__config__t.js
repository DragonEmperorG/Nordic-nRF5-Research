var structnrfx__power__pofwarn__config__t =
[
    [ "handler", "structnrfx__power__pofwarn__config__t.html#a89c4adb28581dd59d4e5d694c81ed772", null ],
    [ "thr", "structnrfx__power__pofwarn__config__t.html#a230d56e37f63d55209f6d9a3274427f5", null ],
    [ "thrvddh", "structnrfx__power__pofwarn__config__t.html#a17a0fb3e5dffd6964c9597cefce9d286", null ]
];