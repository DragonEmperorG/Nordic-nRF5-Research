var structnrf__ble__ots__c__evt__t =
[
    [ "conn_handle", "structnrf__ble__ots__c__evt__t.html#a5ec6bfebf44441e59e71721b051205f3", null ],
    [ "evt_type", "structnrf__ble__ots__c__evt__t.html#a78ea4130935f37bd895f3ae9926475ee", null ],
    [ "feature", "structnrf__ble__ots__c__evt__t.html#a822d0312171079fe95535f9b184edf67", null ],
    [ "handles", "structnrf__ble__ots__c__evt__t.html#a273c15a646999f921427d7585c2745e9", null ],
    [ "object", "structnrf__ble__ots__c__evt__t.html#a5c8c4e674a84ffb74e54231da5f1ffe4", null ],
    [ "params", "structnrf__ble__ots__c__evt__t.html#a9f2253215a89f938fcbcc3018c64b2ba", null ],
    [ "prop", "structnrf__ble__ots__c__evt__t.html#a87c53d5694c7abec2d7cbc532f704999", null ],
    [ "response", "structnrf__ble__ots__c__evt__t.html#a200904d2b43adc02a3be6f7f17204fad", null ],
    [ "size", "structnrf__ble__ots__c__evt__t.html#ae4ccd8ab37ab40536423ca16c66b80e5", null ]
];