var group__nrf__crypto__mem =
[
    [ "NRF_CRYPTO_ALLOC", "group__nrf__crypto__mem.html#ga0bf00a1b98f41c84ecfb1c6f1e70ba12", null ],
    [ "NRF_CRYPTO_ALLOC_ON_STACK", "group__nrf__crypto__mem.html#ga1a5a4afa580132d70d55c8e9fe12154e", null ],
    [ "NRF_CRYPTO_FREE", "group__nrf__crypto__mem.html#gad87a41c9b86b05bc0d49d8b298bf776e", null ]
];