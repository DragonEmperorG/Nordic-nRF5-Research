var structble__rscs__c__s =
[
    [ "conn_handle", "structble__rscs__c__s.html#a32aad4eed5e1cbe38e19e30f5c111e37", null ],
    [ "evt_handler", "structble__rscs__c__s.html#a23f969b6eb09194e0f51c615839fce14", null ],
    [ "peer_db", "structble__rscs__c__s.html#a3de096d1103202231d69c6d5d6a5808e", null ]
];