var unionnrfx__usbd__handler__t =
[
    [ "consumer", "unionnrfx__usbd__handler__t.html#a81809747ea77a2ca79b0e4a3f49cee50", null ],
    [ "feeder", "unionnrfx__usbd__handler__t.html#a5f68a1a03f10880b48b7cd9209f978a4", null ]
];