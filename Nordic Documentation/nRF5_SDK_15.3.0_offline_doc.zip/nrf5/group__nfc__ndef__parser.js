var group__nfc__ndef__parser =
[
    [ "Parser for NDEF messages", "group__nfc__ndef__msg__parser.html", "group__nfc__ndef__msg__parser" ],
    [ "Parser for NDEF records", "group__nfc__ndef__record__parser.html", "group__nfc__ndef__record__parser" ]
];