var group__ant__common__page__70__config =
[
    [ "ANT_COMMON_PAGE_70_ENABLED", "group__ant__common__page__70__config.html#ga6ca2629e32a425cfe1560d49528faec1", null ],
    [ "ANT_COMMON_PAGE_70_INFO_COLOR", "group__ant__common__page__70__config.html#ga37baee02c99386b54d18b2327ede8dbb", null ],
    [ "ANT_COMMON_PAGE_70_LOG_ENABLED", "group__ant__common__page__70__config.html#ga53b38e1a7c788553d23496c10d04b2a2", null ],
    [ "ANT_COMMON_PAGE_70_LOG_LEVEL", "group__ant__common__page__70__config.html#gabdc0da881a0dfd2dd4df685a4ea0c7b3", null ]
];