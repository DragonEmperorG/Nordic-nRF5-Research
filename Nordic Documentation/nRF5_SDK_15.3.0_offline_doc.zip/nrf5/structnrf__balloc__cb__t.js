var structnrf__balloc__cb__t =
[
    [ "max_utilization", "structnrf__balloc__cb__t.html#a638d9a7cb0b7ff3e9418294f23796ee0", null ],
    [ "p_stack_pointer", "structnrf__balloc__cb__t.html#af270fecaad921dabc061cc59013c63fe", null ]
];