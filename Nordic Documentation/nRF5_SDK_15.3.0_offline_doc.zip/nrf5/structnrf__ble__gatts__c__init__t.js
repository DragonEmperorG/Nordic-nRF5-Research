var structnrf__ble__gatts__c__init__t =
[
    [ "err_handler", "structnrf__ble__gatts__c__init__t.html#a8cb394ce0faa7fe4e0a3910cbbd03316", null ],
    [ "evt_handler", "structnrf__ble__gatts__c__init__t.html#abace6c6867fe93db576b95a84fbadd64", null ]
];