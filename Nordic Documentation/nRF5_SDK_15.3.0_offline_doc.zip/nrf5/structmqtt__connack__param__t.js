var structmqtt__connack__param__t =
[
    [ "return_code", "structmqtt__connack__param__t.html#a017cf2e7f4819ece8591686c87ce67e8", null ],
    [ "session_present_flag", "structmqtt__connack__param__t.html#a25e4588d7bdfca3a552f80b446a002a4", null ]
];