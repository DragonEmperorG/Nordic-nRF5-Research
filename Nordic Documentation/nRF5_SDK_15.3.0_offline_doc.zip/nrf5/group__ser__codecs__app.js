var group__ser__codecs__app =
[
    [ "Application common codecs", "group__ser__app__common__codecs.html", "group__ser__app__common__codecs" ],
    [ "Application codecs for S132 and S140", "group__ser__app__s130__codecs.html", "group__ser__app__s130__codecs" ],
    [ "Application codecs for S212", "group__ser__app__s212__codecs.html", "group__ser__app__s212__codecs" ]
];