var group__nrf__ble__ots__c__l2cap__config =
[
    [ "BLE_OTS_C_L2CAP_ENABLED", "group__nrf__ble__ots__c__l2cap__config.html#ga85bb7509ec902d4c384e87154639db37", null ]
];