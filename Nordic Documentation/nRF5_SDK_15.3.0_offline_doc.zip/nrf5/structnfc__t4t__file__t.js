var structnfc__t4t__file__t =
[
    [ "len", "structnfc__t4t__file__t.html#ab0c0f43226bb25973cf92eddb1b4ab21", null ],
    [ "p_content", "structnfc__t4t__file__t.html#a64d6e537c62843bc3ab30cb33bacdb8a", null ]
];