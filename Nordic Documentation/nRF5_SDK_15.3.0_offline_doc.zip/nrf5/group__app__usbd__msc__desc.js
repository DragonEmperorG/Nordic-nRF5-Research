var group__app__usbd__msc__desc =
[
    [ "APP_USBD_MSC_EP_DSC", "group__app__usbd__msc__desc.html#ga2011987fcc8ebcfbc7de9a9726d09455", null ],
    [ "APP_USBD_MSC_INTERFACE_DSC", "group__app__usbd__msc__desc.html#ga50320e398c512d04731749332d805f69", null ]
];