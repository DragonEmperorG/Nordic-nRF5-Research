var structnrf__ble__cgms__evt__t =
[
    [ "evt_type", "structnrf__ble__cgms__evt__t.html#a8735e8df3bd42668c189db92947084ab", null ]
];