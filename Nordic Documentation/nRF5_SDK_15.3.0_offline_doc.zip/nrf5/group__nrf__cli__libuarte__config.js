var group__nrf__cli__libuarte__config =
[
    [ "NRF_CLI_LIBUARTE_ENABLED", "group__nrf__cli__libuarte__config.html#ga26390db27a0e774810d5c03d3d0be5ad", null ],
    [ "NRF_CLI_LIBUARTE_TIMEOUT_RTC_INSTANCE", "group__nrf__cli__libuarte__config.html#ga11976e8802e1988f283ac4d464db9223", null ],
    [ "NRF_CLI_LIBUARTE_TIMEOUT_TIMER_INSTANCE", "group__nrf__cli__libuarte__config.html#gabc893e7007af3439e914863a9e786908", null ],
    [ "NRF_CLI_LIBUARTE_TIMER_INSTANCE", "group__nrf__cli__libuarte__config.html#gac960321942e58c5306ced71ea8b245a0", null ],
    [ "NRF_CLI_LIBUARTE_UARTE_INSTANCE", "group__nrf__cli__libuarte__config.html#ga7a1d86b08ebcf0e9dbc304ba0e97a011", null ]
];