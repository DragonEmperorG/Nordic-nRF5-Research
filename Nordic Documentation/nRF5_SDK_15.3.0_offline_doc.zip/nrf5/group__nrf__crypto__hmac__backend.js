var group__nrf__crypto__hmac__backend =
[
    [ "nrf_crypto_backend_hmac_context_t", "unionnrf__crypto__backend__hmac__context__t.html", [
      [ "hmac_sha256_context", "unionnrf__crypto__backend__hmac__context__t.html#a3f65315c7389ae1c7dff0a2b9d9d432c", null ],
      [ "hmac_sha512_context", "unionnrf__crypto__backend__hmac__context__t.html#a3215b8648a48a3d1135c5cfab934d9ee", null ]
    ] ]
];