var structble__lns__navigation__s =
[
    [ "bearing", "structble__lns__navigation__s.html#af936acffaae9d88342e3aa8034a4de82", null ],
    [ "destination_reached", "structble__lns__navigation__s.html#a80fea1c4a7296f6004c7eb1aefd95521", null ],
    [ "eta", "structble__lns__navigation__s.html#a216e8bcf0fe664b510b69a5e32cd1a12", null ],
    [ "eta_present", "structble__lns__navigation__s.html#ad4e906a362bf29498851f945536bdff2", null ],
    [ "heading", "structble__lns__navigation__s.html#a2ea424f243fae8281176b636b2198fb4", null ],
    [ "heading_source", "structble__lns__navigation__s.html#a813e231ab99283c1da6b442d03535881", null ],
    [ "navigation_indicator_type", "structble__lns__navigation__s.html#a7d7d071bbe62218b46d221b131d0751e", null ],
    [ "position_status", "structble__lns__navigation__s.html#a0bb2e890491000f996c8e4c0e622f0f1", null ],
    [ "remaining_dist_present", "structble__lns__navigation__s.html#a5607bd557f4d2182e5128a72daadc8ff", null ],
    [ "remaining_distance", "structble__lns__navigation__s.html#a48e2421259563a9566ebc3b7c53d8a74", null ],
    [ "remaining_vert_dist_present", "structble__lns__navigation__s.html#ac07746c3da89a5b3173b8996943bb04c", null ],
    [ "remaining_vert_distance", "structble__lns__navigation__s.html#a0b1c1f606525af05790d77e142c3d0ec", null ],
    [ "waypoint_reached", "structble__lns__navigation__s.html#aab6c0ba221ed762a875382a8c69928ca", null ]
];