var structnrf__dfu__request__mtu__t =
[
    [ "size", "structnrf__dfu__request__mtu__t.html#a64c41efdbdbac85a4dee886e897318a5", null ]
];